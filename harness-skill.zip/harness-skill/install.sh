#!/usr/bin/env bash
# Installs the harness personally (~/.claude), available across all your projects.
# Run from inside the unzipped harness-skill/ folder:  bash install.sh
# For a single project instead:  cp -r .claude /path/to/your-project/
set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ ! -d "$SRC/.claude/skills/harness" || ! -d "$SRC/.claude/agents" ]]; then
  echo "Error: run this from inside the unzipped harness-skill/ folder." >&2
  exit 1
fi

mkdir -p "$HOME/.claude/skills" "$HOME/.claude/agents"
cp -r "$SRC/.claude/skills/harness" "$HOME/.claude/skills/harness"
cp "$SRC"/.claude/agents/harness-*.md "$HOME/.claude/agents/"

echo "Installed:"
echo "  ~/.claude/skills/harness/SKILL.md   (the /harness command)"
echo "  ~/.claude/agents/harness-planner.md"
echo "  ~/.claude/agents/harness-developer.md"
echo "  ~/.claude/agents/harness-tester.md"
echo
echo "Next: restart Claude Code (or run /agents) so the subagents load,"
echo "then type /harness to confirm the command is registered."
