## HARNESS — Multi-Agent Development Harness for Claude Code

A `/harness [task]` workflow that drives a feature from requirements through tested,
building code — using **real Claude Code subagents**, each in its own isolated context
window, coordinated by an orchestrator skill.

### Architecture

Four roles, mapped onto the actual Claude Code primitives:

| Role | Primitive | Lives at | Context | Tools |
|------|-----------|----------|---------|-------|
| Orchestrator | Skill (`/harness`) | `.claude/skills/harness/SKILL.md` | main conversation | delegates only |
| Planner | Subagent | `.claude/agents/harness-planner.md` | isolated | Read, Grep, Glob, Write |
| Developer | Subagent | `.claude/agents/harness-developer.md` | isolated | Read, Write, Edit, Bash, Glob, Grep |
| Tester | Subagent | `.claude/agents/harness-tester.md` | isolated | Read, Bash, Glob, Grep (**read-only**) |

Why subagents and not one big prompt:

- **Context isolation** — the developer's file reads, build logs, and test output never
  touch the orchestrator's context. The only thing that flows back is a short summary plus
  the artifact files in `.harness/`. Long sessions stay sharp instead of degrading.
- **Permission-locking** — the tester has no `Write` or `Edit` tool at all. It physically
  cannot modify your code while "verifying" it. Its verdict is trustworthy by construction.
- **Model routing** — the tester is pinned to `sonnet` to cut cost; planner and developer
  inherit your session model. Change either in the agent frontmatter.

The `.harness/*.md` artifact files ARE the inter-agent bus. Each subagent starts fresh and
sees only the prompt the orchestrator hands it, so the orchestrator passes explicit file
paths every stage. This is also why the loop is restartable: state lives on disk, not in
any one agent's memory.

### Install

The skill and the subagents live in **different directories** — that's required, not
optional. Subagents must be in `.claude/agents/`, not inside the skill folder.

**Personal (all your projects):**

```bash
# from the unzipped harness-skill/ folder:
mkdir -p ~/.claude/skills ~/.claude/agents
cp -r .claude/skills/harness ~/.claude/skills/harness
cp .claude/agents/harness-*.md ~/.claude/agents/
```

**Project (this repo only, shareable with your team via git):**

```bash
cp -r .claude /path/to/your-project/
```

Then **restart Claude Code** (or run `/agents`) so the new subagents load — subagents are
read at session start. Verify with `/agents` (you should see the three `harness-*` agents)
and type `/harness` to confirm the command is registered.

### Usage

```
/harness Add a POST /payments endpoint that processes Stripe charges
/harness Build a Redis-backed rate limiter middleware for the Express API
/harness Add a pre-execution policy check to the trust-gate MCP server
```

Or just `/harness` and describe the task when prompted.

What happens:

1. **Variables** — the orchestrator asks a short set of questions once (language,
   framework, build/lint/test commands, env vars). It infers what it can from your repo.
2. **Plan** — `harness-planner` writes `.harness/requirements.md`.
3. **Build** — `harness-developer` implements + tests, lints, builds, writes
   `.harness/dev-handoff.md`.
4. **Test** — `harness-tester` runs the suite and returns a PASS/FAIL report; the
   orchestrator writes `.harness/test-report.md`.
5. **Loop** — on FAIL, developer fixes only the flagged items, tester re-runs. Max 3
   iterations, then it surfaces the report to you.
6. **Done** — clean summary + three artifact files.

### Artifacts

All under `.harness/` in your project root. Commit them for an audit trail or gitignore
them — your call. Add `.harness/` to `.gitignore` if you don't want them tracked.

### Customizing

Everything is plain markdown.

| Change | Edit |
|--------|------|
| Orchestrator flow, loop cap, variable list | `.claude/skills/harness/SKILL.md` |
| Requirements doc structure | `.claude/agents/harness-planner.md` |
| Coding conventions, dependency rules | `.claude/agents/harness-developer.md` |
| Coverage rules, verdict criteria | `.claude/agents/harness-tester.md` |
| Cut tester cost further | set `model: haiku` in `harness-tester.md` frontmatter |
| Let Claude auto-invoke the harness | remove `disable-model-invocation: true` from `SKILL.md` |

After editing any `.claude/agents/*.md` file on disk, restart the session or use `/agents`
to reload — on-disk agent edits don't hot-reload mid-session.

### Notes / gotchas

- Subagent names must be unique across your whole `.claude` tree. These are prefixed
  `harness-` to avoid colliding with any generic `planner`/`tester` you already have.
- Project-scope agents override personal ones of the same name.
- If `/harness` runs but says it can't find a subagent, you almost certainly skipped the
  restart after install.
